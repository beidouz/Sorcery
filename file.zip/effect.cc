#include <string>
#include "effect.h"

using namespace std;

Effect::Effect() {}

Effect::~Effect() {}
