#ifndef _TRIGGERTYPE_H_
#define _TRIGGERTYPE_H_
enum class TriggerType { None, Xwindow, OpponentSummon, YouSummon, AnySummon, StartOfTurn, EndOfTurn, YouDraw, OpponentDraw, YouDestroy, AnyDestroy, OpponentDestroy};
#endif
