#ifndef __INFO_H__
#define __INFO_H__
class Owner;

struct Info {
  const Owner* me;
  const Owner* opponent;
};

#endif
